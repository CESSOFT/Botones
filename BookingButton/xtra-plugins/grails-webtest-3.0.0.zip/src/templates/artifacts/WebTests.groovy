@artifact.package@

class @artifact.name@ extends @artifact.superclass@ {

    // Unlike unit tests, functional tests are sometimes sequence dependent.
    // Methods starting with 'test' will be run automatically in alphabetical order.
    // If you require a specific sequence, prefix the method name (following 'test') with a sequence
    // e.g. test001XclassNameXListNewDelete

   void testSomething() {
        invoke '/'
    }

}