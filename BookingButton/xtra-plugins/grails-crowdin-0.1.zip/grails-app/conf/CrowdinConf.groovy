crowdin {
    projectid = "atest"
    apikey = "6355efc31d083c1eaa50866be0e01e08"
}
